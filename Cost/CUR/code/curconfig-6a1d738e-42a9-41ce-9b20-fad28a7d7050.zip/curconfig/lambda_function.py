import boto3
import json
import logging
import os

client = boto3.client('lambda')
s3 = boto3.resource('s3')

log_level = os.environ['LOG_LEVEL']
logger = logging.getLogger()
logger.setLevel(log_level)

def lambda_handler(event, context):

    curbucket = event['Records'][0]['s3']['bucket']['name']
    curkey = event['Records'][0]['s3']['object']['key']
    s3.meta.client.download_file(os.environ['CUR_PUBLISH_CONFIG_BUCKET'], os.environ['CUR_PUBLISH_CONFIG_KEY'], '/tmp/curpublish.conf')
    with open('/tmp/curpublish.conf') as fp:
        for cnt, line in enumerate(fp):
            line = json.loads(line)
            line["curbucket"] = curbucket
            line["curkey"] = curkey

            logger.info("Invoking Lambda %a for account %s",os.environ['CUR_PUBLISH_LAMBDA_NAME'],line['publishaccount'] )
            response = client.invoke_async(
                FunctionName=os.environ['CUR_PUBLISH_LAMBDA_NAME'],
                InvokeArgs=json.dumps(line)
            )



