import awswrangler as wr
import pandas as pd
import boto3
import time
import logging
import os

log_level = os.environ['LOG_LEVEL']
logger = logging.getLogger()
logger.setLevel(log_level)

def lambda_handler(event, context):

    curfile = 's3://' + event['curbucket'] + '/' + event['curkey']

    publishusageaccount = []
    for acct in event['publishusageaccount']:
        publishusageaccount.append(acct)
    
    df = wr.s3.read_csv(curfile, compression='infer')
    df1=df[df['lineItem/UsageAccountId'].isin(publishusageaccount)] 
    path1 =  's3://' + event['publishbucket'] + '/' + event['publishprefix'] + '/' + 'cur_' +  str(int(time.time())) + '.csv.gz'

    if 'publishrole' in event:
        sts_client = boto3.client('sts')
        assumedRoleObject = sts_client.assume_role(
                RoleArn=event['publishrole'],
                RoleSessionName="NewAccountRole"
            )
        logger.info("For account %s upload S3 file %s",event['publishaccount'],path1 )
        wr.s3.to_csv(df1,
                     path1,
                     index=False,
                     boto3_session=boto3.Session(aws_access_key_id=assumedRoleObject['Credentials']['AccessKeyId'],
                                                 aws_secret_access_key=assumedRoleObject['Credentials']['SecretAccessKey'],
                                                 aws_session_token=assumedRoleObject['Credentials']['SessionToken'],
                                                 region_name=event['publishregion']
                                                 ),
                     s3_additional_kwargs={'ServerSideEncryption': 'AES256'}
                    )
    else:
        logger.info("For account %s upload S3 file %s",event['publishaccount'],path1 )
        wr.s3.to_csv(df1, path1, index=False)
    